//20241128

#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Account;
class Bank;
class ATM;
class Card;
class ATM;

class Card {
private:
    size_t card_num = 0;
    size_t card_pwd = 0;
    string bankName = "신한";
public:
    Card(size_t num, size_t pwd) {
        card_num = num;
        card_pwd = pwd;
    }
    size_t getCardNum() { return card_num; }
    size_t getCardPWD() { return card_pwd; }
    string getBankName() { return bankName; }
};

class Account {
    string Bankname;
    size_t accountNumber;
    int balance;
    bool primary;
    void descibe() {
        cout << "계좌가 입력되었습니다. 은행 : " << Bankname << " 계좌번호 : " << accountNumber << " 잔액 : " << balance << endl;
    }
public:
    Account(string bankname, size_t accountnumber, int initialbalance) {
        Bankname = bankname;
        accountNumber = accountnumber;
        balance = initialbalance;
        descibe();
    }
    size_t getNumber() { return accountNumber; }
    void addBalance(int amount) { balance += amount; }
    int getBalance() const { return balance; }
    void setPrimaryStatus(int primaryStatus) {
        if (primaryStatus == 1) {
            primary = true;  // 주요 계좌로 설정
        }
        else if (primaryStatus == 2) {
            primary = false; // 비주요 계좌로 설정
        }
        else {
            cout << "유효하지 않은 입력입니다. 1 또는 2를 입력하세요." << endl;
        }
    }
    // 주요 계좌 여부를 반환
    bool isPrimaryAccount() const { return primary; }

};
class Withdraw {
    ATM* atm = nullptr;               // ATM 포인터
    Account* account = nullptr;       // 연결된 계좌
    size_t transactionfee = 0;           // 수수료
    bool continueTransaction = false; // 거래 진행 여부

public:
    Withdraw(ATM* atmPtr, Account* acc) : atm(atmPtr), account(acc) {}
    bool getContinueTransaction() { return continueTransaction; }
    void Transactionfee();
    void execute(int money);
};
class Transfer {
    ATM* atm = nullptr;                // ATM 포인터
    Account* fromAccount = nullptr;    // 보내는 계좌
    Account* toAccount = nullptr;      // 받는 계좌
    bool continueTransaction = false; // 거래 진행 여부
    int transactionfee = 0;            // 수수료
public:
    Transfer(ATM* atmPtr, Account* acc, Account* toacc) : atm(atmPtr), fromAccount(acc), toAccount(toacc) {}
    // 이체 수수료 설정
    bool getContinueTransaction() { return continueTransaction; }
    void Transactionfee();
    // 이체 수수료 부과 (transfer의 경우 입금받는금액에서 수수료를 제외하고 전달)
    void execute(int money);
};
class Deposit {
    string t_name;
    ATM* atm = nullptr;
    Account* useraccount = nullptr;    // 계좌
    size_t transactionfee = 0;         // 수수료
    bool continueTransaction = false;
public:
    Deposit(ATM* atmPtr, Account* acc) : atm(atmPtr), useraccount(acc) {}
    void Transactionfee();
    void execute(size_t money);
};
class ATM {
private:
    static size_t transactionID ;
    static const size_t denominations[4];
    size_t atmCash = 0;                // ATM의 총 현금
    size_t checkvalue = 0;             // 수표 금액
    bool continueATM = true;           // ATM 계속 실행 여부
    size_t numDenominations = 0;       // 입금된 지폐의 종류 수
    vector<size_t> cashInventory = { 10, 10, 10, 10 }; // 각 지폐의 재고
    size_t transactionType = 0;        // 거래 유형
    Withdraw* withdraw = nullptr;      // 출금 객체
    Transfer* transfer = nullptr;      // 이체 객체
    Deposit* deposit = nullptr;        // 입금 객체
    Account* useraccount = nullptr;    // 사용자 계좌
    Account* toaccount = nullptr;      // 상대방 계좌
    size_t cur_lang;
    
public:
    size_t numberOfUses = 0;
    size_t transferType = 0;
    ATM() : cashInventory({ 10, 10, 10, 10 }), continueATM(true), atmCash(0) {}
    ~ATM() {
        delete useraccount;
        delete toaccount;
    }

    const size_t* getDenominations() const { return denominations; }
    // ATM의 잔액은 각 지폐 개수 x 지폐 값 , ATM 현금 잔액 확인 함수
    size_t calatmCash() {
        atmCash = 0;
        for (size_t i = 0; i < 4; i++) {
            atmCash += cashInventory[i] * denominations[i];
        }
        return atmCash;
    }
    void setATMcurLang(size_t ko_eng) { cur_lang = ko_eng; }
    size_t getATMcurLang() { return cur_lang; }
    
    void checkcurrentATM(size_t money) { checkvalue += money; } // 수표입금시에 필요

    //ATM 전체 잔액 확인 함수
    size_t getcurrentATM() {
        calatmCash();
        return (atmCash + checkvalue);
    }

    void startATM() { // ATM  생성 함수 -> 여기서 ATM 객체를 만들어야함, 우선 계좌 입력만 받기로 시작.
        string bankname;
        size_t accountnumber;
        if (cur_lang == 1) {
            cout << "사용자의 계좌를 입력해주세요\n" << "은행: ";
        }
        
        else if (cur_lang == 2)
        {
            cout << "Enter your account number \n" << "Bank: ";
        }
        cin >> bankname;
        
        if (cur_lang == 1) {
            cout << "계좌번호: ";
        }
        
        else if (cur_lang ==2 ) {
            cout << "Account number: ";
        }
        
        cin >> accountnumber;

        useraccount = new Account(bankname, accountnumber, 1000000); // 우선 연결되는 계좌의 초기잔액은 100만원으로 가정.
        chooseTransaction();

    }

    // 지폐를 분배하는 함수
    vector<size_t> calculateDenominations(size_t money) {
        vector<size_t> result(4, 0);

        for (size_t i = 0; i < 4; ++i) {
            if (money <= 0) break;
            // 현재 지폐 재고와 요청 금액을 비교해 사용 가능 개수 결정
            size_t maxUsableNotes = min(cashInventory[i], money / denominations[i]);
            result[i] = maxUsableNotes;
            money -= maxUsableNotes * denominations[i];
        }

        // 금액을 정확히 나누지 못한 경우
        if (money > 0) {
            result.clear(); // 나눌 수 없는 경우 빈 벡터 반환
        }
        return result;
    }

    void describe() {
        if (cur_lang == 1 )
        {
            cout << "현재 ATM의 지폐 상태: " << endl;
        }
        
        else if (cur_lang == 2) {
            cout << "The current status of the ATM's banknotes: " << endl;
        }
        
        for (size_t i = 0; i < 4; ++i) {
            if (cur_lang == 1) {
                cout << denominations[i] << "원 지폐: " << cashInventory[i] << "장" << endl;
            }
            
            else if (cur_lang == 2) {
                cout << denominations[i] << "Won banknotes:  " << cashInventory[i] << "sheets" << endl;
            }
        }
        if (cur_lang == 1) {
            cout << "ATM 전체 잔액: " << getcurrentATM() << "원" << endl;
        }
        
        else if (cur_lang == 2) {
            cout << "Total balance in the ATM: " << getcurrentATM() << "Won" << endl;
        }
    }

    void addCashInventory(const vector<size_t>& denominationsAdded) {
        for (size_t i = 0; i < 4; ++i) {
            cashInventory[i] += denominationsAdded[i];
        }
        if ( cur_lang == 1 ) {
            cout << "ATM 지폐가 추가되었습니다." << endl;
        }
        
        else if ( cur_lang == 2 ) {
            cout << "Banknotes have been added to the ATM." << endl;
        }
    }

    bool removeCashInventory(const vector<size_t>& denominationsUsed) {
        for (size_t i = 0; i < 4; ++i) {
            if (cashInventory[i] < denominationsUsed[i]) {
                if ( cur_lang == 1 ) {
                    cout << "ATM에 " << denominations[i] << "원 지폐가 부족합니다." << endl;
                }
                
                else if ( cur_lang == 2 ) {
                    cout << "The ATM is running low on " << denominations[i] << "won banknotes." << endl;
                }
                return false; // 실패 시 반환
            }
        }
        for (size_t i = 0; i < 4; ++i) {
            cashInventory[i] -= denominationsUsed[i];
        }
        if (cur_lang ==1)
        {
            cout << "ATM 지폐가 차감되었습니다." << endl;
        }
        
        else if (cur_lang == 2) {
            cout << "Banknotes have been deducted from the ATM." << endl;
        }
        
        return true; // 성공 시 반환
    }

    void performWithdraw() {
        int money;
        size_t withdrawContinue;
        Withdraw withdraw(this, useraccount);
        if (cur_lang == 1) {
            cout << "얼마를 출금하시겠습니까?: ";
        }
        else if (cur_lang == 2) {
            cout << "How much would you like to withdraw?: ";
        }
        cin >> money;

        //출금 금액이 지폐로 반환이 안되는 경우
        if (money % 1000 != 0) {
            if (cur_lang == 1)
            {
                cout << "인출은 지폐만 가능합니다.";
                
            }
            
            else if (cur_lang==2) {
                cout << "Withdrawals are only available in banknotes." << endl;
            }
            
            return;
        }
        // 거래 가능 횟수를 초과한 경우
        if (numberOfUses == 3) {
            if (cur_lang == 1){
                cout << "출금 가능 횟수를 초과하였습니다. 거래를 종료합니다." << endl;
            }
            
            else if (cur_lang ==2) {
                cout << "You have exceeded the maximum number of withdrawals. The transaction will be terminated." << endl;
            }
            return;
        }
        // 한도 초과
        if (money > 500000) {
            if (cur_lang == 1 )
            {   cout << "출금 가능 한도를 초과하였습니다." << endl; }
            
            else if (cur_lang ==2) {
                cout << "You have exceeded the withdrawal limit." << endl;
            }
            numberOfUses += 1;
            return;
        }
        // ATM 한도 부족
        if (money > getcurrentATM()) {
            if (cur_lang ==1 ) {
                cout << "ATM 잔액이 충분하지 않습니다." << endl;
            }
            
            else if (cur_lang == 2) {
                cout << "The ATM does not have sufficient balance." << endl;
            }
            numberOfUses += 1;
            return;
        }
        withdraw.execute(money);

        if (withdraw.getContinueTransaction()) {
            auto denominationsUsed = calculateDenominations(money);
            if (denominationsUsed.empty()) {
                if (cur_lang == 1) {
                    cout << "ATM 지폐 상태로 인해 금액을 처리할 수 없습니다." << endl;
                }
                else if (cur_lang ==2) {
                    cout << "The amount cannot be processed due to the ATM's banknote status." << endl;
                }
                return;
            }
            if (removeCashInventory(denominationsUsed)) { // 지폐 차감 성공 여부 확인(근데 이 지폐 차감도 withdraw 클래스에서 구현해야하나?)
                numberOfUses += 1;
                if (cur_lang == 1)
                    { cout << "출금 완료 " << money << "원이 출금되었습니다. 계좌 현재 잔액: " << useraccount->getBalance() << endl; }
                else if (cur_lang==2) {
                    cout << "Withdrawal complete " << money << "Won has been withdrawn. Current account balance: " << useraccount->getBalance() << endl;
                }
                describe();
            }
            if (cur_lang==1) {
                cout << "출금을 계속하시겠습니까? 1. 예   2. 아니요";
            }
            
            else if (cur_lang==2) {
                cout << "Would you like to continue withdrawing? 1. Yes    2. No";
            }
            cin >> withdrawContinue;
            if (withdrawContinue == 1) {
                performWithdraw();
            }
            else { return; }
        }
    }
    // 이체 실행
    void performTransfer() {
        size_t money;
        string bankname;
        size_t accountnumber;
        vector<size_t> denominationsAdded(4, 0);
        size_t totalAmount = 0; // 총 입금 금액
        if (cur_lang==1) {
            cout << "이체 유형을 선택하세요:\n1. 현금 이체\n2. 계좌 이체\n입력: ";
        }
        else if (cur_lang==2) {
            cout << "Please select the type of transfer:\n1. Cash Transfer\n2. Account Transfer\nInput: ";
        }
        cin >> transferType;
        if (cur_lang==1){
            cout << "상대방의 계좌 은행을 입력해주세요.\n" << " 은행 : ";
        }
        else if (cur_lang==2){
            cout << "Please enter the recipient's bank.\n" << " Bank: ";
        }
        cin >> bankname;
        if (cur_lang ==1) {
            cout << "상대방의 계좌 번호를 입력해주세요.\n" << " 계좌 : ";
        }
        else if (cur_lang ==2 ) {
            cout << "Please enter the recipient's account number.\n" << " Account : ";
        }
        cin >> accountnumber;
        // 입력한 계좌 은행과 계좌로 toAccount 생성

        toaccount = new Account(bankname, accountnumber, 0);

        Transfer transfer(this, useraccount, toaccount);

        // 현금 이체(현금 to 계좌)
        if (transferType == 1) { // 무통장 입금
            if (cur_lang == 1) {
                cout << "현금을 입금하여 이체합니다.\n";
            }
            else if (cur_lang == 2){
                cout << "Transferring by depositing cash.\n";
            }
            if (cur_lang==1) {
                cout << "몇 개의 지폐를 입금하시겠습니까?: ";
            }
            
            else if (cur_lang == 2) {
                cout << "How many banknotes would you like to deposit?: ";
            }
            cin >> numDenominations;

            // 유효하지 않은 지폐 수
            if (numDenominations <= 0) {
                if (cur_lang ==1 ) {
                    cout << "유효하지 않은 지폐 수입니다." << endl;
                }
                
                else if (cur_lang == 2) {
                    cout << "The number of banknotes is invalid." << endl;
                }
                return;
            }
            // 지폐 개수가 50장을 초과할 때
            if (numDenominations > 50) {
                if (cur_lang == 1) {
                    cout << "입금 가능한 지폐 개수를 초과하였습니다." << endl;
                }
                else if (cur_lang==2) {
                    cout << "You have exceeded the allowable number of depositable banknotes." << endl;
                }
                return;
            }

            // 지폐 단위별로 수량 입력 받기
            for (int i = 0; i < numDenominations; ++i) {
                if (cur_lang == 1) {
                    cout << "입금할 지폐 금액을 입력하세요 (예: 1000, 5000, 10000, 50000): ";
                }
                
                else if (cur_lang == 2) {
                    cout << "Please enter the denomination of banknotes to deposit (e.g., 1000, 5000, 10000, 50000): ";
                }
                int note;
                cin >> note;

                // 입력된 금액이 유효한지 확인
                auto it = find(begin(denominations), end(denominations), note);
                if (it != end(denominations)) {
                    size_t index = distance(begin(denominations), it);
                    denominationsAdded[index]++;
                    totalAmount += note; // 총 입금 금액에 추가
                }
                else {
                    if (cur_lang == 1) {
                        cout << "잘못된 지폐 금액입니다. 다시 입력하세요." << endl;
                    }
                    else if (cur_lang == 2) {
                        cout << "Invalid banknote denomination. Please enter again." << endl;
                    }
                    --i; // 다시 입력 기회를 제공
                }
            }
            // ATM에 지폐 추가
            addCashInventory(denominationsAdded);
            //atmCash += totalAmount; // ATM 총 금액 업데이트
            // 이체 실행
            transfer.execute(totalAmount);

            if (transfer.getContinueTransaction()) {
                if (cur_lang == 1) {
                    cout << "이체가 완료되었습니다. 계좌 현재 잔액 : " << useraccount->getBalance() << endl;
                }
                
                else if (cur_lang == 2) {
                    cout << "The transfer has been completed. Current account balance : " << useraccount->getBalance() << endl;
                }
            }
            else { return; }
        }
        // 계좌 이체(계좌 to 계좌)
        if (transferType == 2) {
            if (cur_lang == 1) {
                cout << "계좌 이체를 진행합니다. 얼마를 이체하시겠습니까?: ";
            }
            else if (cur_lang == 2) {
                cout << "Proceeding with account transfer. How much would you like to transfer?: ";
            }
            cin >> money;
            transfer.execute(money);
            if (transfer.getContinueTransaction() == true) {
                if (cur_lang == 1) {
                    cout << "이체가 완료되었습니다. 계좌 현재 잔액 : " << useraccount->getBalance() << endl;
                }
                else if (cur_lang==2) {
                    cout << "The transfer has been completed. Current account balance : " << useraccount->getBalance() << endl;
                }
                describe();
            }
            else { return; }
        }
    }
    void performDeposit() {
        Deposit deposit(this, useraccount);
        if (cur_lang == 1) {
            cout << "입금 종류를 선택해주세요.  1.현금   2.수표\n";
        }
        else if (cur_lang == 2) {
            cout << "Please select the type of deposit. 1. Cash 2. Check\n";
        }
        cin >> transferType;
        // 현금 입금 진행
        if (transferType == 1) {
            vector<size_t> denominationsAdded(4, 0);
            if (cur_lang == 1) {
                cout << "몇 개의 지폐를 입금하시겠습니까?: ";
            }
            else if (cur_lang == 2) {
                cout << "How many banknotes would you like to deposit?: ";
            }
            
            cin >> numDenominations;
            if (numDenominations > 50) {
                if (cur_lang == 1) {
                    cout << "한도를 초과한 지폐 수입니다." << endl;
                }
                
                else if (cur_lang == 2) {
                    cout << "The number of banknotes exceeds the limit." << endl;
                }
                return;
            }
            size_t totalAmount(0);
            for (int i = 0; i < numDenominations; ++i) {
                if (cur_lang == 1) {
                    cout << "입금할 지폐 금액을 입력하세요 (예: 1000, 5000, 10000, 50000): ";
                }
                
                else if (cur_lang == 2) {
                    cout << "Please enter the denomination of banknotes to deposit (e.g., 1000, 5000, 10000, 50000): ";
                }
                size_t note;
                cin >> note;

                auto it = find(begin(denominations), end(denominations), note);
                if (it != end(denominations)) {
                    size_t index = distance(begin(denominations), it);
                    denominationsAdded[index]++;
                    totalAmount += note;
                }
                else {
                    if (cur_lang == 1) {
                        cout << "잘못된 지폐 금액입니다. 다시 입력하세요." << endl;
                    }
                    else if (cur_lang == 2) {
                        cout << "Invalid banknote denomination. Please try again." << endl;
                    }
                }
            }
            deposit.execute(totalAmount);
            addCashInventory(denominationsAdded);
            if (cur_lang == 1) {
                cout << "입금 성공: " << totalAmount << "원이 계좌에 입금되었습니다." << endl;
                cout << "계좌 현재 잔액 : " << useraccount->getBalance() << endl;
            }
            else if (cur_lang == 2) {
                cout << "Deposit Successful: " << totalAmount << "Won has been deposited into your account." << endl;
                cout << "Current account balance : " << useraccount->getBalance() << endl;
            }
        }
        // 수표 입금 진행
        else if (transferType == 2) {
            size_t numChecks(0);
            size_t totalAmount(0);
            if (cur_lang == 1) {
                cout << "몇 개의 수표를 입금하시겠습니까?: ";
            }
            else if (cur_lang == 2) {
                cout << "How many checks would you like to deposit?: ";
            }
            cin >> numChecks;

            if (numChecks > 50) {
                if (cur_lang == 1) {
                    cout << "에러: 한도를 초과한 수표 수입니다." << endl;
                }
                
                else if (cur_lang == 2) {
                    cout << "Error: The number of checks exceeds the limit." << endl;
                }
                return;
            }
            vector<int> checks(numChecks);
            for (int i = 0; i < numChecks; ++i) {
                if (cur_lang == 1) {
                    cout << "수표 금액을 입력하세요: ";
                }
                else if (cur_lang == 2) {
                    cout << "Please enter the check amount: ";
                }
                
                cin >> checks[i];
                if (checks[i] < 100000) {
                    if (cur_lang == 1 ) {
                        cout << "에러: 수표 금액이 최소 금액을 충족하지 못합니다." << endl;
                    }
                    else if (cur_lang == 2) {
                        cout << "Error: The check amount does not meet the minimum required amount." << endl;
                    }
                    return;
                }
                totalAmount += checks[i];
            }
            deposit.execute(totalAmount);
            checkcurrentATM(totalAmount);
            if (cur_lang == 1) {
                cout << "입금 성공: " << totalAmount << "원이 계좌에 입금되었습니다. 계좌 현재 잔액 : " << useraccount->getBalance() << endl;
            }
            else if (cur_lang == 2) {
                cout << "Deposit Successful: " << totalAmount << "Won has been deposited into your account. Current account balance : " << useraccount->getBalance() << endl;
            }
            describe();
        }
        // 1,2 이외의 다른 선택을 골랐을 때
        else {
            if (cur_lang == 1 ) {
                cout << "잘못된 입력입니다. 다시 선택해주세요.\n";
            }
            else if (cur_lang == 2) {
                cout << "Invalid input. Please make a selection again.\n";
            }
            performDeposit();
        }
    }
    void chooseTransaction() {
        continueATM = true;
        while (continueATM) {
            if (cur_lang == 1) {
                cout << "원하시는 거래 유형을 선택하세요:\n";
                cout << "1. 출금\n" << "2. 이체\n" << "3. 입금\n" << "4. 종료\n" << "입력: ";
            }
            else if (cur_lang == 2) {
                cout << "Please select the type of transaction you want:\n";
                cout << "1. Withdrawal\n" << "2. Transfer\n" << "3. Deposit\n" << "4. Exit\n" << "Input: ";
            }
            cin >> transactionType;

            // 거래 유형 선택
            if (transactionType == 1) {
                performWithdraw(); // 출금 실행
                transactionID++;
            }
            else if (transactionType == 2) {
                performTransfer(); // 이체 실행
                transactionID++;
            }
            else if (transactionType == 3) {
                performDeposit(); // 입금 실행
                transactionID++;
            }
            else if (transactionType == 4) {
                if (cur_lang == 1) {
                    cout << "ATM을 종료합니다." << endl;
                }
                else if (cur_lang == 2) {
                    cout << "Shutting down the ATM." << endl;
                }
                continueATM = false; // 루프 종료
                break;// 루프 종료
            }
            else {
                if (cur_lang == 1) {
                    cout << "유효하지 않은 입력입니다. 다시 시도해주세요.";
                }
                else if (cur_lang == 2 ) {
                    cout << "Invalid input. Please try again.";
                }
                continue;
            }
        }
    }
};

const size_t ATM::denominations[4] = { 50000, 10000, 5000, 1000 };
size_t ATM::transactionID = 1;

void Withdraw::Transactionfee() {
    if (account->isPrimaryAccount()) {
        transactionfee = 1000;
    }
    else {
        transactionfee = 2000;
    }
    cout << "출금 수수료는 " << transactionfee << "원 입니다. 수수료를 입금해주세요: ";
}
void Withdraw::execute(int money) {
    int getTransferFee; // 수수료 입금 변수
    vector<size_t> denominationsAdded(4, 0); // 지폐별 추가될 수량
    size_t totalEntered = 0;                 // 입력받은 총 금액
    const size_t* denominations = atm->getDenominations();
    Transactionfee();

    while (true) {
        cout << "수수료를 입력하세요: ";
        cin >> getTransferFee;

        // 수수료가 정확히 transferFee와 같을 때만 진행
        if (getTransferFee == transactionfee) {
            while (totalEntered < transactionfee) {
                cout << "현재 부족한 금액: " << transactionfee - totalEntered << "원\n";
                cout << "지폐 금액을 입력하세요 (예: 1000, 5000, 10000, 50000): ";
                size_t note;
                cin >> note;
                // 입력된 지폐가 유효한지 확인
                auto it = find(denominations, denominations + 4, note);
                if (it != denominations + 4) {
                    size_t index = distance(denominations, it); // 유효 범위로 계산
                    if (index < denominationsAdded.size()) {   // 벡터 접근 전 유효성 검사
                        denominationsAdded[index]++;
                        totalEntered += note;

                        // 입력된 금액이 정확히 transferFee와 같을 때만 진행
                        if (totalEntered == transactionfee) {
                            atm->addCashInventory(denominationsAdded);
                            cout << transactionfee << "원이 입금되었습니다. 출금을 진행합니다." << endl;
                            account->addBalance(-money);          // 계좌 잔액 차감
                            continueTransaction = true;
                            return;
                        }
                        else if (totalEntered > transactionfee) {
                            cout << "초과 금액을 입력하셨습니다. 정확한 금액을 다시 입력해주세요.\n";
                            totalEntered -= note; // 초과 금액 취소
                            denominationsAdded[index]--;
                        }
                    }
                    else {
                        cout << "지폐 인덱스가 잘못되었습니다. 다시 시도해주세요." << endl;
                    }
                }
                else {
                    cout << "잘못된 지폐 금액입니다. 다시 입력하세요." << endl;
                }
            }
        }
        else {
            cout << "수수료를 잘못 입력하셨습니다. 다시 시도해주세요: ";
        }
    }
}

void Transfer::Transactionfee() {
    if (atm->transferType == 1) {
        if (toAccount->isPrimaryAccount()) {
            transactionfee = 2000;
        }
        else {
            transactionfee = 3000;
        }
    }
    else {
        if (fromAccount->isPrimaryAccount() && toAccount->isPrimaryAccount()) {
            transactionfee = 2000;
        }
        else if (fromAccount->isPrimaryAccount() || toAccount->isPrimaryAccount()) {
            transactionfee = 3000;
        }
        else {
            transactionfee = 4000;
        }
    }
    cout << "수수료는 " << transactionfee << "원 입니다. 수수료를 입력해주세요\n";
}
void Transfer::execute(int money) {
    vector<size_t> denominationsAdded(4, 0); // 지폐별 추가될 수량
    size_t totalEntered = 0;                 // 입력받은 총 금액
    const size_t* denominations = atm->getDenominations();
    size_t getTransferfee;
    Transactionfee();
    // 현금이체일 경우(like 무통장입금)
    if (atm->transferType == 1) {
        while (true) {
            cout << "수수료를 입력하세요: ";
            cin >> getTransferfee;

            // 수수료가 정확히 transactionfee와 같아야 함
            if (getTransferfee == transactionfee) {
                while (totalEntered < transactionfee) {
                    cout << "현재 부족한 금액: " << transactionfee - totalEntered << "원\n";
                    cout << "지폐 금액을 입력하세요 (예: 1000, 5000, 10000, 50000): ";
                    size_t note;
                    cin >> note;

                    // 입력된 지폐가 유효한지 확인
                    auto it = find(denominations, denominations + 4, note);
                    if (it != denominations + 4) {
                        size_t index = distance(denominations, it);
                        if (index < denominationsAdded.size()) {
                            denominationsAdded[index]++;
                            totalEntered += note; // 총 금액에 추가

                            // 정확히 transactionfee에 도달했을 경우
                            if (totalEntered == transactionfee) {
                                atm->addCashInventory(denominationsAdded); // 지폐 반영
                                cout << transactionfee << "원이 입금되었습니다. 거래를 진행합니다.\n";
                                toAccount->addBalance(money); // 상대 계좌에 잔액 추가
                                continueTransaction = true;
                                return;
                            }
                            // 초과 금액 처리
                            else if (totalEntered > transactionfee) {
                                cout << "초과 금액을 입력하셨습니다. 정확한 금액을 다시 입력해주세요.\n";
                                totalEntered -= note; // 초과 금액 취소
                                denominationsAdded[index]--;
                            }
                        }
                        else {
                            cout << "지폐 인덱스가 잘못되었습니다. 다시 시도해주세요.\n";
                        }
                    }
                    else {
                        cout << "잘못된 지폐 금액입니다. 다시 입력하세요.\n";
                    }
                }
            }
            else {
                cout << "수수료를 잘못 입력하셨습니다. 다시 입력해주세요.\n";
            }
        }
    }
    // 계좌이체일 경우
    else {
        if (fromAccount->getBalance() >= (transactionfee + money)) {
            fromAccount->addBalance(-(money + transactionfee)); //이체금액에 수수료를 더한 값만큼 인출 계좌에서 빠짐
            toAccount->addBalance(money); //상대 계좌에 잔액 추가
            continueTransaction = true;
        }
        else {
            cout << "거래의 잔액이 부족합니다." << endl;
            continueTransaction = false;
            return;
        }
    }
}
void Deposit::Transactionfee() {
    if (useraccount->isPrimaryAccount()) { transactionfee = 1000; }
    else { transactionfee = 2000; }
    cout << "출금 수수료는 " << transactionfee << "원 입니다.";
}
void Deposit::execute(size_t money) {
    int getTransferFee; // 수수료 입금 변수
    vector<size_t> denominationsAdded(4, 0); // 지폐별 추가될 수량
    size_t totalEntered = 0;                 // 입력받은 총 금액
    const size_t* denominations = atm->getDenominations(); // ATM의 지폐 단위
    Transactionfee(); // 수수료 계산 함수 호출

    while (true) {
        cout << "수수료를 입력하세요: ";
        cin >> getTransferFee;

        // 수수료가 정확히 transactionfee와 같아야만 진행
        if (getTransferFee == transactionfee) {
            while (totalEntered < transactionfee) {
                cout << "현재 부족한 금액: " << transactionfee - totalEntered << "원\n";
                cout << "지폐 금액을 입력하세요 (예: 1000, 5000, 10000, 50000): ";
                size_t note;
                cin >> note;

                // 입력된 지폐가 유효한지 확인
                auto it = find(denominations, denominations + 4, note);
                if (it != denominations + 4) {
                    size_t index = distance(denominations, it); // 유효 범위로 계산
                    if (index < denominationsAdded.size()) {   // 벡터 접근 전 유효성 검사
                        denominationsAdded[index]++;
                        totalEntered += note;

                        // 입력된 금액이 정확히 transactionfee와 같을 때 처리
                        if (totalEntered == transactionfee) {
                            atm->addCashInventory(denominationsAdded); // 수수료 지폐 ATM에 추가
                            cout << "수수료 " << transactionfee << "원이 입금되었습니다. 입금을 진행합니다." << endl;

                            // 입금 금액을 계좌에 추가
                            useraccount->addBalance(money);
                            return; // 함수 종료
                        }
                    }
                    else if (totalEntered > transactionfee) { // 초과 금액 처리
                        cout << "초과 금액을 입력하셨습니다. 정확한 금액을 다시 입력해주세요.\n";
                        totalEntered -= note; // 초과 금액 취소
                        denominationsAdded[index]--;
                    }
                }
                else {
                    cout << "잘못된 지폐 금액입니다. 다시 입력하세요." << endl;
                }
            }
        }
        else {
            cout << "수수료를 잘못 입력하셨습니다. 다시 시도해주세요: ";
        }
    }
}


int main() {
    ATM atm;
    atm.startATM();

    return 0;
}
