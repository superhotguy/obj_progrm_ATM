#include <iostream>
#include <string>
#include <limits> // std::numeric_limits

using namespace std;

size_t selectInput(string a, string b) {
    size_t num;
    while (true) {
        cout << "1. " << a << "\t2. " << b << endl; // 형식: "질문\n1.xx  2.xx\n"
        cin >> num;

        if (cin.fail()) { // 입력이 실패한 경우
            cin.clear(); // 실패 상태를 초기화
            cin.ignore(1000, '\n'); // 입력 버퍼 비우기
            cout << "숫자를 입력하십시오." << endl;
        } else if (!(num == 1 || num == 2)) { // 1 또는 2가 아닌 경우
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // 입력 버퍼 비우기
            cout << "잘못된 입력입니다. 1 또는 2 중 원하는 동작을 선택하십시오(숫자 입력)." << endl;
        } else { // 올바른 입력
            return num;
        }
    }
}

int main() {
    string option1 = "Option A";
    string option2 = "Option B";

    size_t choice = selectInput(option1, option2);
    cout << "선택한 옵션: " << choice << endl;

    return 0;
}
