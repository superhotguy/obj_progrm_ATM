#include <iostream>
#include <string>
using namespace std;
/*  USER AUTHORIZATION  */

// Bank class에서 인증 진행
// authorization func
// ATM이 card 정보를 Bank로 보내서 
class Account {
private:
    //Bank* bankList[10];
    //Card* CardList[10];
    string userName;
    size_t accNum = 0;
};

class Card {
private:
    size_t card_num = 0;
    size_t card_pwd = 0;
    string bankName = "신한";
public:
    Card(size_t num, size_t pwd);
    size_t getCardNum() { return card_num; }
    size_t getCardPWD() { return card_pwd; }
    string getBankName() { return bankName; }

};

class Bank {
private:
    string bankName;
    //ATM* atmList[10];
    //Account* accList[10];
public:
    Bank(string name);
    bool authorize(Card* card, size_t pwd);  // 성공하면 TRUE return 아니면 나중에 필요한 내용 return
    string getBankName() { return bankName; }
};

class ATM {
private:
    Bank* bank;
    Card* activeCard;
    void print_history();
    int atmType = 1;    // 1: Single Bank, 2: Multi Bank
    bool auth = false;  // authorization이 한번 되면 세션 끝날 때까지 할 필요 없음
public:
    ATM(Bank* bank);
    void cardIn(Card* card);
    void admin(Card* card);
    int getAtmType() { return atmType; }
    
};

Bank::Bank(string name) : bankName(name) {
    cout << "Bank " << name << " Constructed." << endl;
}

ATM::ATM(Bank* bank) : bank(bank) {
    cout << "ATM Constructed." << endl;
}

Card::Card(size_t num, size_t pwd) : card_num(num), card_pwd(pwd) {
    cout << "Card Constructed." << endl;
}

void ATM::print_history() {
    cout << "ID: , Card Number: , Transaction Type: , Amount: , other-specific information: " << endl;
}

bool Bank::authorize(Card* card, size_t pwd) {
    if (pwd == card->getCardPWD()) return true;
    else return false;
}
void ATM::admin(Card* card) {
    size_t show_transac;
    cout << "0. Transaction History" << endl;
    cin >> show_transac;
    if (show_transac == 0) {
        print_history();
    }
}

// user가 card를 집어넣음 -> 숫자로 넣을거라서 숫자랑 카드랑 매치하는 걸 해야함!
void ATM::cardIn(Card* card) {
    activeCard = card;

    /* Admin Menu */
    if (card->getCardNum() == 0) {
        admin(card);
        return;
    }
    /* 1. valid 검증 */
    // single Bank ATM -> primary bank에서 issue 된 것만 valid
    // multi Bank ATM -> 다른 bank에서 발급된 것도 valid
    int valid = false;
    if (atmType == 1) {
        if (card->getBankName() == bank->getBankName()) { valid = true; }
    } else if (atmType == 2) {
        valid = true;
    }
    else {
        cout << "\n----------\n| Invalid Card |\n----------\n" << endl;
        // 카드 재삽입
    }

    /* 2. authorization */
    if (valid == true) {
        int password;
        for (size_t i = 0; i < 3; i++) {
            cout << "\n---------\n| Enter Password |\n--------\n" << endl;
            cin >> password;
            if (bank->authorize(card, password)) {
                auth = true;
                break;
            } else {
                cout << "\n--------\n| Wrong Password |\n--------\n" << endl;
            }
        }
        if (auth == false) {      // 3번 연속 틀리면 return card
            cout << "\n--------\n| Session aborted, Take your card. |\n--------\n" << endl;
            activeCard = nullptr;
        }
        cout << "\n------\n| Transaction Start |\n--------\n" << endl;
    }
}


int main() {
    Bank bank1 = Bank("신한");
    ATM atm1 = ATM(&bank1);
    Card card1 = Card(1234, 1234);
    size_t card;
    cout << "카드번호: ";
    cin >> card;
    atm1.cardIn(&card1);
}





// transaction started