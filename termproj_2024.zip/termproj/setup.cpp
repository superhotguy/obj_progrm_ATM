#include <iostream>
#include <string>
#include <vector>
#include <stdexcept>

using namespace std;

size_t numInput();
class Account;
class Bank;
class ATM;
class Card;


class Bank {
private:
    string bankName;
    vector<Account*> accList;
    vector<ATM*> atmList;
public:
    Bank(string name);
    bool authorize(Card* card, size_t pwd);  // 성공하면 TRUE return 아니면 나중에 필요한 내용 return
    string getBankName() { return bankName; }
    void addBankAccountList(Account* acc) { accList.push_back(acc); }
    vector<Account*> getBankAccountList() { return accList; }
};


class Account {
private:
    string bankName;
    string userName;
    size_t accNum = 0;
    size_t availableFund = 0;
    vector<Card*> cardList;     // card를 여러개 소지할 수 있다.
public:
    Account(string bankName, string userName, size_t accountNum, size_t availableFund, vector<Card*>cardList);
    size_t getAccNum() { return accNum; }
    string getAccBankname() { return bankName; }
    string getAccUsername() { return userName; }
    void addAccCardList(Card* card) { cardList.push_back(card); }
    vector<Card*> getAccCardList() { return cardList; }
};


class ATM {
private:
    Bank* bank;
    Card* activeCard;
    string serialNum;
    vector<Bank*> bankInWorld;          // multi bank일 때 필요함..
    void print_history();
    bool auth = false;  // authorization이 한번 되면 세션 끝날 때까지 할 필요 없음
    size_t numberOfUses;
    size_t primaryATM;    // 1: Single Bank, 2: Multi Bank
    size_t langType;    // 1: unilang, 2: bilang
    size_t cur_lang;    // 1. Korean, 2: English
    size_t cash_1000;   // 천원 개수
    size_t cash_5000;
    size_t cash_10000;
    size_t cash_50000;
    vector<size_t> fund;    // 수표
public:
    ATM(Bank* bank, vector<Bank*> bankInWorld, string serialNum, size_t type, size_t langType, size_t c_1000, size_t c_5000, size_t c_10000, size_t c_50000);
    void cardIn(Card* card);
    void admin(Card* card);
    size_t getATMType() { return primaryATM; }
    string getATMNumber() { return serialNum; }
    size_t getATMlangType() { return langType; }
    void setATMcurLang(size_t ko_eng) { cur_lang = ko_eng; }
    size_t getATMcurLang() { return cur_lang; }
    size_t ssSelectInput(string a, string b);
    size_t ssNumInput();
    void startSession();
    void endSession();
};

class Card {
private:
    Account* account;
    size_t card_num = 0;
    size_t card_pwd = 0;
public:
    Card(Account* acc, size_t num, size_t pwd);
    size_t getCardNum() { return card_num; }
    size_t getCardPWD() { return card_pwd; }
    Account* getCardAcc() { return account; }
};


// [Bank] Methods
Bank::Bank(string name) : bankName(name) {
    cout << name << " 은행이 설립되었습니다." << endl;
}

Account::Account(string bN, string uN, size_t aN, size_t aF, vector<Card*> c_lst) {
    bankName = bN; userName = uN; accNum = aN; availableFund = aF; cardList = c_lst;
    cout << uN << "님의 계좌가 개설되었습니다." << endl;
    cout << "# 계좌 정보 \n  - 주거래은행: " << bN << "\n  - 계좌번호: " << aN << "\n  - 계좌 잔액: " << aF << "\n" << endl;
}

ATM::ATM(Bank* b, vector<Bank*> whole_b, string sNum, size_t type, size_t lang, size_t c_1000, size_t c_5000, size_t c_10000, size_t c_50000) {
    bank = b; bankInWorld = whole_b, serialNum = sNum; primaryATM = type; langType = lang; cash_1000 = c_1000; cash_5000 = c_5000; cash_10000 = c_10000; cash_50000 = c_50000;
    cout << b->getBankName() << "은행의 ATM 기기가 설치되었습니다.\n";
    cout << "# ATM 정보\n  - ATM 시리얼넘버: " << sNum << "\n  - ATM Type: " << ((type == 1) ? "Single-Bank ATM" : "Multi-Bank ATM") << "\n  - Language Type: " << ((lang == 1) ? "Unilingual" : "Bilingual") << endl;
}

Card::Card(Account* acc, size_t num, size_t pwd) : account(acc), card_num(num), card_pwd(pwd) {
    cout << acc->getAccUsername() << "님의 카드가 발급되었습니다." << endl;
    cout << "# 카드 정보\n  - 카드 번호: " << num << "\n  - 카드 비밀번호: " << pwd << "\n" << endl;
}

void ATM::print_history() {
    cout << "ID: , Card Number: , Transaction Type: , Amount: , other-specific information: " << endl;
}

bool Bank::authorize(Card* card, size_t pwd) {
    if (pwd == card->getCardPWD()) return true;
    else return false;
}
void ATM::admin(Card* card) {
    size_t show_transac;
    cout << "0. Transaction History" << endl;
    cin >> show_transac;
    if (show_transac == 0) {
        print_history();
    }
}

// user가 card를 집어넣음 -> 숫자로 넣을거라서 숫자랑 카드랑 매치하는 걸 해야함!
void ATM::cardIn(Card* card) {
    activeCard = card;

    /* Admin Menu */
    if (card->getCardNum() == 0) {
        admin(card);
        return;
    }
    /* 1. valid 검증 */
    // single Bank ATM -> primary bank에서 issue 된 것만 valid
    // multi Bank ATM -> 다른 bank에서 발급된 것도 valid
    bool valid = false;
    if (primaryATM == 1) {
        if (card->getCardAcc()->getAccBankname() == bank->getBankName()) { valid = true; }
        else { 
            valid = false;
            cout << card->getCardAcc()->getAccBankname() << "은행에서 유효하지 않은 카드입니다." << endl;
            endSession();
        }
    } else if (primaryATM == 2) {
        valid = true;
    }

    /* 2. authorization */
    if (valid == true) {
        size_t password;
        for (size_t i = 0; i < 3; i++) {
            cout << "비밀번호를 입력하세요." << endl;
            password = ssNumInput();
            if (bank->authorize(card, password)) {
                auth = true;
                break;
            } else {
                cout << "비밀번호가 틀렸습니다." << endl;
            }
        }
        if (auth == false) {      // 3번 연속 틀리면 return card
            cout << "비밀번호를 3회 틀려 세션이 종료되었습니다. 카드를 가져가십시오." << endl;
            activeCard = nullptr;
            endSession();
        } else {
            cout << "원하시는 거래의 종류를 선택하십시오." << endl;
        }
    }
}

// SetUP
size_t selectInput(string a, string b) {      // 1. 2. 전용
    size_t num;
    while (true) {
        cout << "1. " << a << "\t2. " << b << endl;      // 형식은 "질문\n1.xx  2.xx\n"
        cin >> num;
        if (cin.fail()) {
            cin.clear();     // 입력 버퍼 비우기
            cin.ignore(1000, '\n');
            cout << "숫자를 입력하십시오." << endl;
        } else if(!(num == 1 || num == 2)) {   // 1/2중 선택을 하지 않는다면
            cin.ignore(1000, '\n');
            cout << "잘못된 입력입니다. 1 또는 2 중 원하는 동작을 선택하십시오(숫자 입력)." << endl;
        } else {
            return num;
        }
    }
}

size_t numInput() {
    size_t num;
    while (true) {
        cin >> num;
        if (cin.fail()) {
            cin.clear();
            cin.ignore(1000, '\n');
            cout << "\n숫자를 입력하십시오. >> ";
        } else { return num; }
    }
}

size_t ATM::ssSelectInput(string a, string b) {  // session 시작되고, x 누르면 벗어나야함,,
    string input;
    while (true) {
        cout << "1. " << a << "\t2. " << b << endl; // 형식은 "질문\n1.xx  2.xx\n"
        cin >> input;
        if (input == "x") {     // x가 입력되면 세션 시작
            endSession();
            startSession();
            return 0;
        }

        // string -> size_t로 바꾸기 시도
        try {
            size_t num = stoul(input);
            if (!(num == 1 || num == 2)) {
                cout << "잘못된 입력입니다. 1 또는 2 중 원하는 동작을 선택하십시오(숫자 입력)." << endl;
            } else {
                return num;
            }
        } catch (invalid_argument& param) {
            cout << "숫자를 입력하십시오." << endl;
        }
    }
}

size_t ATM::ssNumInput() {
    string input;
    while (true) {
        cin >> input;
        if (input == "x") {
            endSession();
            startSession();
            return 0;
        }

        try {
            size_t num = stoul(input);
            return num;
        } catch (invalid_argument& param) {
            cout << "\n숫자를 입력하십시오. >> ";
        }
    }
}


Bank* findBank(string bankName, vector<Bank*> BankInWorld) {
    for (Bank* bank : BankInWorld) {
        if (bank != nullptr) {
            if (bank->getBankName() == bankName) {
                return bank;
            }
        }
    }
    return nullptr;
}

ATM* findATM(string atm_num, vector<ATM*> ATMInWorld) {
    for (ATM* atm : ATMInWorld) {
        if (atm != nullptr) {
            if (atm->getATMNumber() == atm_num) {
                return atm;
            }
        }
    }
    return nullptr;
}

Card* findCard(size_t cardNum, vector<Bank*> BankInWorld) {
    cout << BankInWorld.size() << endl;
    for (Bank* bank : BankInWorld) {
        if (bank == nullptr) {
            continue;
        }
        vector<Account*> accList = bank->getBankAccountList();
        if (accList.empty()) { continue; }

        for (Account* acc : accList) {
            vector<Card*> cardList = acc->getAccCardList();
            if(cardList.empty()) { continue; }

            for (Card* card : cardList) {
                if (card->getCardNum() == cardNum) {
                    return card;
                }
            }
        }
    }
    return nullptr;  // 카드가 없으면 nullptr 반환
}

void ATM::startSession() {  // 여기부터 영어 적용
    size_t cardNum = 0;
    size_t flag = 1;
    Card* card;
    do {
        if (cur_lang == 1) { cout << "\n카드를 삽입해주세요: "; }
        else if (cur_lang == 2) { cout << "\nInsert Card: "; }
        cardNum = ssNumInput();
        card = findCard(cardNum, bankInWorld);
        if (card == nullptr) {          // (REQ 3.2)
            if (cur_lang == 1) { cout << "유효하지 않은 카드입니다.\n"; }
            else if (cur_lang = 2) { cout << "Invalid Card.\n"; }
        } else { flag = 2; }
    } while(flag == 1);
    cardIn(card);
}

void ATM::endSession() {
    //delete가 되어야함
    cout << "세션이 종료됩니다. 카드를 다시 삽입해주세요." << endl;
}


string getATMNum() {    // ATM Number 규칙에 맞게 받기
    string ATMNum;
    while (true) {
        cout << "ATM의 시리얼넘버를 입력하세요(6자리): ";
        cin >> ATMNum;
        size_t notNum = 0;
        for (char x : ATMNum) { if (x < '0' || x > '9') { notNum = 1; } }
        if (ATMNum.length() != 6 || notNum == 1) {      // (REQ1.1)6자리가 아니거나 숫자 아닌 값을 포함하면
            cout << "ATM의 Serial Number는 6자리 숫자이어야합니다." << endl;
        } else {    // 정상 입력 경우
            return ATMNum;
        }
    }
}


void makeNewBank(vector<Bank*>& BankInWorld) {            // Initialize bank
    string bankName;
    cout << "======== NEW BANK ========\nBank name: ";
    cin >> bankName;
    BankInWorld.push_back(new Bank(bankName));
}

void makeNewAccount(vector<Bank*> BankInWorld) {
    size_t more_card = 1;
    size_t flag = 1;
    string bankName;
    string userName;
    size_t accountNumber;
    size_t availableFund;
    vector<Card*> cardList;
    cout << "======== NEW ACCOUNT ========\n계좌의 주거래 은행을 입력하세요: ";
    do {
        cin >> bankName;
        if (findBank(bankName, BankInWorld) != nullptr) { flag = 2; }   // 존재하면 while 룹 벗어남
        else { cout << "\n현재 존재하지 않는 은행입니다. 주거래 은행을 다시 입력하세요. >> "; }
    } while ( flag == 1);
    cout << "사용자 이름을 입력하세요: ";
    cin >> userName;
    cout << "계좌번호를 입력하세요: ";
    accountNumber = numInput();
    cout << "계좌에 있는 금액을 입력하세요: ";
    availableFund = numInput();
    cout << endl;
    Account* new_acc = new Account(bankName, userName, accountNumber, availableFund, cardList);
    do {
        size_t cardNumber;
        size_t cardPwd;
        if (cardList.size() == 10) {
            cout << "더 이상 카드를 발급할 수 없습니다." << endl;
            break;
        } else {
            cout << "카드번호를 입력하세요: ";
            cardNumber = numInput();
            cout << "카드 비밀번호를 입력하세요: ";
            cardPwd = numInput();
            new_acc->addAccCardList(new Card(new_acc, cardNumber, cardPwd));
            cout << "\n다른 카드를 만들고 싶나요?\n";
            more_card = selectInput("네", "아니요");
        }
    } while(more_card == 1);
    findBank(bankName, BankInWorld)->addBankAccountList(new_acc);
}

void makeNewATM(vector<ATM*>& ATMInWorld, vector<Bank*> BankInWorld) {
    size_t flag = 1;
    string bankName;
    Bank* bank;
    string serialNum;
    size_t type;
    size_t langType;
    size_t cash_1000;
    size_t cash_5000;
    size_t cash_10000;
    size_t cash_50000;
    cout << "======== NEW ATM ========\nATM의 은행을 입력하세요: ";
    do {
        cin >> bankName;
        if (findBank(bankName, BankInWorld) != nullptr) { flag = 2; }   // 존재하면 while 룹 벗어남
        else { cout << "\n현재 존재하지 않는 은행입니다. 주거래 은행을 다시 입력하세요. >> "; }
    } while ( flag == 1 );
    serialNum = getATMNum();
    cout << "Single-Bank ATM이라면 1, Multi-Bank ATM이라면 2를 입력해주세요.\n";
    type = selectInput("Single-Bank", "Multi-Bank");
    cout << "설치하시는 ATM이 한국어만 지원한다면 1, 영어도 지원한다면 2를 입력해주세요.\n";
    langType = selectInput("Unilangual", "Bilangual");
    cout << "Cash(천원권): ";
    cash_1000 = numInput();
    cout << "Cash(오천원권): ";
    cash_5000 = numInput();
    cout << "Cash(만원권): ";
    cash_10000 = numInput();
    cout << "Cash(오만원권): ";
    cash_50000 = numInput();
    cout << "현재 잔액: " << cash_10000*10000+cash_5000*5000+cash_1000*1000+cash_50000*50000 << endl;
    bank = findBank(bankName, BankInWorld);
    ATMInWorld.push_back(new ATM(bank, BankInWorld, serialNum, type, langType, cash_1000, cash_5000, cash_10000, cash_50000));
}

void printATMNumbers(const vector<ATM*>& ATMInWorld) {
    if (ATMInWorld.empty()) {
        cout << "ATM 리스트가 비어 있습니다." << endl;
        return;
    }

    cout << "[";
    for (size_t i = 0; i < ATMInWorld.size(); ++i) {
        ATM* atm = ATMInWorld[i];
        if (atm == nullptr) {
            continue; // Null ATM은 생략
        }
        cout << atm->getATMNumber();
        if (i != ATMInWorld.size() - 1) {
            cout << ", ";  // 마지막 원소 뒤에는 쉼표를 출력하지 않음
        }
    }
    cout << "]" << endl;
}




/* SETUP */
/*
main() func에서 해야하는 일
1. initial Bank / initial Account / initial ATM 만들기
2. 잘 만들어졌는지 정보 확인
3. 세션 시작
*/

int main() {
    size_t flag = 1;
    vector<Bank*> BankInWorld;      // 전체 bank list
    vector<ATM*> ATMInWorld;
    cout << "============ WORLD CREATION =============" << endl;
    
    do { 
        makeNewBank(BankInWorld);
        cout << "\n다른 은행을 만들고 싶나요?\n";
        flag = selectInput("네", "아니요");
    } while (flag == 1);

    cout << "======== END CREATING BANKS ========" << endl;

    do {
        makeNewAccount(BankInWorld);
        cout << "\n다른 계좌를 생성하시겠습니까?\n";
        flag = selectInput("네", "아니요");
    } while (flag == 1);

    cout << "======== END CREATING ACCOUNTS ========" << endl;

    do {
        makeNewATM(ATMInWorld, BankInWorld);
        cout << "\n다른 ATM기기를 만들겠습니까?\n";
        flag = selectInput("네", "아니요");
    } while (flag == 1);

    cout << "======== END CREATING ATMS ========" << endl;

    // START SESSION
    string ATMNum;
    size_t ATMlang = 0;

    cout << "현재 존재하는 ATM: ";
    printATMNumbers(ATMInWorld);    // ATM 확인
    //@@ 여기 넘어가는 거 확인하김..
    // ATM 확인
    ATM* atm;
    flag = 1;
    do {
        ATMNum = getATMNum();
        atm = findATM(ATMNum, ATMInWorld);
        if (atm == nullptr) {
            cout << "ATM이 존재하지 않습니다. 다른 시리얼넘버를 입력하세요.\n";
        } else { flag = 2; }
    } while(flag == 1);

    if (atm->getATMlangType() == 1) {   // unilang이면 영어만 사용
        atm->setATMcurLang(2);
    } else {                            // bilang이면 고르게
        cout << "원하시는 언어를 선택해주세요.(Please choose the language.)\n";
        ATMlang = selectInput("한국어(Korean)", "영어(English)");
        atm->setATMcurLang(ATMlang);
    }
    atm->startSession();
    
    return 0;
}