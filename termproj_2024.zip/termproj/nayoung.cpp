#include <iostream>
#include <string>
#include <vector>

using namespace std;

// Forward declaration
class VendingMachine;

// State abstract class
class State {
public:
    virtual void ejectCoin(VendingMachine* machine) = 0;
    virtual void dispense(VendingMachine* machine, string productName) = 0;
    virtual string getName() const = 0;
    virtual ~State() {}
};

// Product abstract class
class Product {
private:
    static int nextId;
    int id;
    string p_name;
    double p_price;
    double p_calorie;

public:
    Product(string name, double price, double calorie)
        : p_name(name), p_price(price), p_calorie(calorie) {
        id = ++nextId;
        cout << "[Constructor] Product created: " << p_name << " (ID: " << id << ", Price: $" << p_price << ")\n";
    }

    virtual ~Product() {
        cout << "[Destructor] Product destroyed: " << p_name << " (ID: " << id << ")\n";
    }

    string getName() const { return p_name; }
    double getPrice() const { return p_price; }
    int getId() const { return id; }
    double getCalories() const { return p_calorie; }

    virtual void describe() const = 0;
};

int Product::nextId = 0;

class Beverage : public Product {
public:
    Beverage(string name, double price, double calorie)
        : Product(name, price, calorie) {
        cout << "Beverage created: " << name << " (" << calorie << " calories)\n";
    }

    void describe() const override {
        cout << "Beverage: " << getName() << " (ID: " << getId()
             << ", Price: $" << getPrice()
             << ", Calories: " << getCalories() << " calories)\n";
    }
};

class Snack : public Product {
public:
    Snack(string name, double price, double calorie)
        : Product(name, price, calorie) {
        cout << "Snack created: " << name << " (" << calorie << " calories)\n";
    }

    void describe() const override {
        cout << "Snack: " << getName() << " (ID: " << getId()
             << ", Price: $" << getPrice()
             << ", Calories: " << getCalories() << " calories)\n";
    }
};

// VendingMachine class declaration
class VendingMachine {
private:
    State* noCoinState;
    State* hasCoinState;
    State* soldOutState;
    State* currentState;
    static const int MAX_NUM_PRODUCT = 10;
    vector<Product*> inventory;
    bool hasCoin;
    double coinValue;


    void printState(string action) const {
        cout << "Action: " << action << " | Current State: "
             << currentState->getName() << " | Coin Value: " << coinValue << "\n";
    }
public:
    VendingMachine();
    ~VendingMachine();
    void setState(State* state);
    void ejectCoin();
    void dispense(string productName);
    Product* removeProduct(string productName);
    void addProduct(Product* product);
    bool isProductAvailable(string productName) const;
    double getProductPrice(string productName) const;
    void displayInventory() const;
    int getInventoryCount() const;
    State* getNoCoinState() const { return noCoinState; }
    State* getHasCoinState() const { return hasCoinState; }
    State* getSoldOutState() const { return soldOutState; }
    State* getCurrentState() const { return currentState; }
    bool hasInsertedCoin() const { return hasCoin; }
    void setCoinInserted(bool inserted) { hasCoin = inserted; }
    double getCoinValue() const { return coinValue; }
    void resetCoinValue() { coinValue = 0.0; }
    void addCoinValue(double coin) { coinValue += coin; }
    VendingMachine& operator+(double coin);
    VendingMachine& operator+(Product* product);
};

// State subclasses
class NoCoinState : public State {
public:
    NoCoinState() {
        cout << "[Constructor] Constructing State: No Coin\n";
    }
    ~NoCoinState() {
        cout << "[Destructor] Destructing State: No Coin\n";
    }

    void ejectCoin(VendingMachine* machine) override {
        cout << "No coins to return.\n";
    }

    void dispense(VendingMachine* machine, string productName) override {
        cout << "Please insert coins first.\n";
    }

    string getName() const override { return "No Coin"; }
};

class HasCoinState : public State {
public:
    HasCoinState() {
        cout << "[Constructor] Constructing State: Has Coin\n";
    }
    ~HasCoinState() {
        cout << "[Destructor] Destructing State: Has Coin\n";
    }

    void ejectCoin(VendingMachine* machine) override {
        cout << "Returning coins: $" << machine->getCoinValue() << "\n";
        machine->resetCoinValue();
        machine->setCoinInserted(false);
        State* prevState = machine->getCurrentState();
        machine->setState(machine->getNoCoinState());
        if (prevState != machine->getCurrentState()) {
            machine->printState("State Changed");
        }
    }

    void dispense(VendingMachine* machine, string productName) override {
        if (!machine->isProductAvailable(productName)) {
            cout << "Product not available.\n";
            return;
        }
        double price = machine->getProductPrice(productName);
        if (machine->getCoinValue() >= price) {
            Product* product = machine->removeProduct(productName);
            if (product) {
                product->describe();
            }
            double change = machine->getCoinValue() - price;
            if (change > 0) {
                cout << "Change returned: $" << change << "\n";
            }
            machine->resetCoinValue();
            machine->setCoinInserted(false);
            State* prevState = machine->getCurrentState();
            if (machine->getInventoryCount() == 0) {
                machine->setState(machine->getSoldOutState());
            } else {
                machine->setState(machine->getNoCoinState());
            }
            if (prevState != machine->getCurrentState()) {
                machine->printState("State Changed");
            }
            if (product) {
                delete product;
            }
        } else {
            cout << "Insufficient funds. Please insert more coins.\n";
            cout << "Current balance: $" << machine->getCoinValue()
                 << ", Required: $" << price << "\n";
        }
    }

    string getName() const override { return "Has Coin"; }
};

class SoldOutState : public State {
public:
    SoldOutState() {
        cout << "[Constructor] Constructing State: Sold Out\n";
    }
    ~SoldOutState() {
        cout << "[Destructor] Destructing State: Sold Out\n";
    }

    void ejectCoin(VendingMachine* machine) override {
        cout << "No coins to return.\n";
    }

    void dispense(VendingMachine* machine, string productName) override {
        cout << "No product to dispense\n";
    }

    string getName() const override { return "Sold Out"; }
};

// VendingMachine method implementations
VendingMachine::VendingMachine() : hasCoin(false), coinValue(0.0) {
    cout << "[Constructor] Constructing VendingMachine\n";
    noCoinState = new NoCoinState();
    hasCoinState = new HasCoinState();
    soldOutState = new SoldOutState();
    currentState = noCoinState;
    printState("Initialization");
}

VendingMachine::~VendingMachine() {
    for (auto product : inventory) {
        delete product;
    }
    cout << "[Destructor] Destructing VendingMachine\n";
    delete noCoinState;
    delete hasCoinState;
    delete soldOutState;
}

void VendingMachine::setState(State* state) {
    currentState = state;
    // 상태 변경 시 즉시 출력하지 않고, 필요한 곳에서 출력하도록 수정
}

void VendingMachine::ejectCoin() {
    currentState->ejectCoin(this);
    printState("Eject Coin");
}

void VendingMachine::dispense(string productName) {
    currentState->dispense(this, productName);
    printState("Dispense");
}

Product* VendingMachine::removeProduct(string productName) {
    for (auto it = inventory.begin(); it != inventory.end(); ++it) {
        if ((*it)->getName() == productName) {
            Product* product = *it;
            inventory.erase(it);
            return product;
        }
    }
    return nullptr;
}

void VendingMachine::addProduct(Product* product) {
    if (inventory.size() < MAX_NUM_PRODUCT) {
        inventory.push_back(product);
        cout << "Added to inventory: ";
        product->describe();
        State* prevState = currentState;
        if (currentState == soldOutState) {
            setState(noCoinState);
            if (prevState != currentState) {
                printState("State Changed");
            }
        }
    } else {
        cout << "Cannot add more products, inventory full.\n";
    }
}

bool VendingMachine::isProductAvailable(string productName) const {
    for (const auto& product : inventory) {
        if (product->getName() == productName) {
            return true;
        }
    }
    return false;
}

double VendingMachine::getProductPrice(string productName) const {
    for (const auto& product : inventory) {
        if (product->getName() == productName) {
            return product->getPrice();
        }
    }
    return 0.0;
}

void VendingMachine::displayInventory() const {
    cout << "Current Inventory:\n";
    for (const auto& product : inventory) {
        product->describe();
    }
    cout << "Total items: " << getInventoryCount() << "\n";
}

int VendingMachine::getInventoryCount() const {
    return inventory.size();
}

// Operator overloading for inserting coins
VendingMachine& VendingMachine::operator+(double coin) {
    if (currentState == soldOutState) {
        cout << "SOLD OUT: No additional coin accepted\n";
        printState("Insert Coin");
        return *this;
    }
    State* prevState = currentState;
    addCoinValue(coin);
    if (!hasCoin) {
        hasCoin = true;
        setState(hasCoinState);
    }
    if (prevState != currentState) {
        printState("State Changed");
    }
    printState("Insert Coin");
    return *this;
}

// Operator overloading for adding products
VendingMachine& VendingMachine::operator+(Product* product) {
    addProduct(product);
    return *this;
}

// Main function
int main() {
    cout << "==========Part 1==========" << endl;
    VendingMachine machine;
    // Add some products using operator overloading
    machine + new Beverage("Cola", 1.50, 330);
    machine + new Snack("Chips", 1.00, 150);
    machine + new Beverage("Water", 1.00, 500);
    machine.displayInventory();
    cout << "==========Part 2==========" << endl;
    // Demonstrate item-specific dispensing with operator overloading for coins
    machine + 1.00 + 0.50; // Insert $1.50
    machine.dispense("Cola"); // Should dispense Cola
    machine + 1.00; // Insert $1.00
    machine.dispense("Water"); // Should dispense Water
    cout << "==========Part 3==========" << endl;
    machine + 0.50; // Insert $0.50
    machine.dispense("Chips"); // Should say insufficient funds
    machine + 0.50; // Insert additional $0.50
    machine.dispense("Chips"); // Should dispense Chips
    cout << "==========Part 4==========" << endl;
    machine + 1.00; // Insert $1.00
    machine.dispense("Candy"); // Should say product not available
    machine.displayInventory();
    cout << "==========Part 5==========" << endl;
    // Add more products
    machine + new Snack("Chocolate", 1.25, 200);
    machine + new Beverage("Orange Juice", 1.75, 250);
    machine.displayInventory();
    cout << "==========Part 6==========" << endl;
    // Dispense remaining products
    machine + 2.00;
    machine.dispense("Chocolate");
    machine + 2.00;
    machine.dispense("Orange Juice");
    machine.displayInventory();
    return 0;
}
